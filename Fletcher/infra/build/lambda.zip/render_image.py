import io
import os
from datetime import datetime

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError as e:
    raise ImportError(
        "Pillow (PIL) is required to render PNGs. Ensure the Lambda has the Pillow layer attached."
    ) from e


def _format_utc(ts: str) -> str:
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        return dt.strftime("%H:%M %d %b")
    except Exception:
        return str(ts)


def _load_large_font(size: int = 40):
    try:
        here = os.path.dirname(__file__)
        font_path = os.path.join(here, "fonts", "Jersey20-Regular.ttf")
        return ImageFont.truetype(font_path, size)
    except Exception:
        return ImageFont.load_default()


def _load_label_font(size: int = 16):
    try:
        here = os.path.dirname(__file__)
        font_path = os.path.join(here, "fonts", "Silkscreen-Regular.ttf")
        return ImageFont.truetype(font_path, size)
    except Exception:
        return ImageFont.load_default()


def _draw_large_height(draw: "ImageDraw.ImageDraw", font: "ImageFont.ImageFont", value_m: float, decimal_x: int, y: int, color: str):
    s = f"{float(value_m):.2f}"
    if "." in s:
        int_part, frac_part = s.split(".", 1)
    else:
        int_part, frac_part = s, "00"

    dot = "."
    try:
        int_w = draw.textlength(int_part, font=font)
        dot_w = draw.textlength(dot, font=font)
    except Exception:
        int_w = font.getlength(int_part)
        dot_w = font.getlength(dot)

    draw.text((decimal_x - int_w, y), int_part, fill=color, font=font)
    draw.text((decimal_x, y), dot, fill=color, font=font)
    draw.text((decimal_x + dot_w, y), frac_part, fill=color, font=font)


def _draw_station_graph(draw: "ImageDraw.ImageDraw", font: "ImageFont.ImageFont", station: dict, x0: int, y0: int):
    heights = station.get("heights_m") or []
    y_axis_top_m = station.get("y_axis_top_m")
    y_axis_bottom_m = station.get("y_axis_bottom_m")
    top_of_normal_range_m = station.get("top_of_normal_range_m")
    highest_ever_recorded_m = station.get("highest_ever_recorded_m")
    first_ts = station.get("first_timestamp_utc", "")
    last_ts = station.get("last_timestamp_utc", "")

    title_h = 12
    label_h = 12
    graph_width = 200
    graph_height = 100

    title_y = y0
    top_y = y0 + title_h
    base_y = top_y + graph_height
    x_axis_end = x0 + graph_width

    old_fontmode = getattr(draw, "fontmode", None)
    try:
        draw.fontmode = "1"
    except Exception:
        pass

    draw.text((x0, title_y), str(station.get("name", "")), fill="black", font=font)

    draw.line([(x0, base_y), (x_axis_end, base_y)], fill="black", width=1)
    draw.line([(x0, base_y), (x0, top_y)], fill="black", width=1)
    draw.line([(x_axis_end, base_y), (x_axis_end, top_y)], fill="black", width=1)

    first_label = _format_utc(first_ts)
    last_label = _format_utc(last_ts)
    draw.text((x0, base_y + 2), first_label, fill="black", font=font)
    draw.text((x_axis_end - 80, base_y + 2), last_label, fill="black", font=font)

    if not isinstance(y_axis_bottom_m, (int, float)):
        y_axis_bottom_m = 0.0

    if (
        isinstance(y_axis_top_m, (int, float))
        and isinstance(y_axis_bottom_m, (int, float))
        and y_axis_top_m > y_axis_bottom_m
    ):
        y_range = float(y_axis_top_m) - float(y_axis_bottom_m)
        draw.text((x_axis_end + 5, base_y - 6), f"{float(y_axis_bottom_m):g}m", fill="black", font=font)
        draw.text((x_axis_end + 5, top_y - 6), f"{y_axis_top_m:g}m", fill="black", font=font)

        def draw_ref_line(value_m, label: str):
            if not isinstance(value_m, (int, float)):
                return
            if value_m < 0:
                return

            y = base_y - int(round(((float(value_m) - float(y_axis_bottom_m)) / y_range) * graph_height))
            if y < top_y:
                y = top_y
            if y > base_y:
                y = base_y

            draw.line([(x0, y), (x_axis_end + 15, y)], fill="black", width=1)
            label_x = x_axis_end + 20
            draw.text((label_x, y - 6), f"{float(value_m):g}m", fill="black", font=font)
            draw.text((label_x, y + 6), label, fill="black", font=font)

        draw_ref_line(top_of_normal_range_m, "Normal")
        draw_ref_line(highest_ever_recorded_m, "Record")

    try:
        if old_fontmode is not None:
            draw.fontmode = old_fontmode
    except Exception:
        pass

    if (
        isinstance(y_axis_top_m, (int, float))
        and isinstance(y_axis_bottom_m, (int, float))
        and y_axis_top_m > y_axis_bottom_m
        and len(heights) == 200
    ):
        y_range = float(y_axis_top_m) - float(y_axis_bottom_m)
        for i, h in enumerate(heights):
            x = x0 + 1 + i
            try:
                v = float(h)
            except Exception:
                continue

            bar_h = int(round(((v - float(y_axis_bottom_m)) / y_range) * graph_height))
            if bar_h < 0:
                bar_h = 0
            if bar_h > graph_height:
                bar_h = graph_height
            if bar_h == 0:
                continue

            # Use red if value >= top_of_normal_range
            color = "black"
            if isinstance(top_of_normal_range_m, (int, float)) and v >= top_of_normal_range_m:
                color = "red"

            draw.line([(x, base_y), (x, base_y - bar_h)], fill=color, width=1)

    return title_h + graph_height + label_h


def _render_latest_image(river_doc: dict) -> "Image.Image":
    """Generate 3-color image with red elements when river >= top_of_normal_range."""
    img = Image.new("RGB", (400, 300), "white")
    draw = ImageDraw.Draw(img)
    label_font = _load_label_font(8)
    large_font = _load_large_font(70)
    station_font = _load_large_font(26)
    small_font = _load_label_font(8)

    utc_time = river_doc.get("utc_time", "")
    try:
        dt = datetime.fromisoformat(utc_time.replace("Z", "+00:00"))
        time_label = dt.strftime("%I:%M %p").lstrip("0")
        date_label = dt.strftime("%d %b %Y")
    except Exception:
        time_label = str(utc_time)
        date_label = ""

    try:
        time_w = draw.textlength(time_label, font=station_font)
    except Exception:
        time_w = station_font.getlength(time_label)

    updated_date_label = f"Updated {date_label}".strip()
    try:
        updated_date_w = draw.textlength(updated_date_label, font=small_font)
    except Exception:
        updated_date_w = small_font.getlength(updated_date_label)

    right_margin = 10
    x_time = 400 - right_margin - time_w
    x_updated_date = 400 - right_margin - updated_date_w

    old_fontmode = getattr(draw, "fontmode", None)
    try:
        draw.fontmode = "1"
    except Exception:
        pass

    draw.text((x_updated_date, 1), updated_date_label, fill="black", font=small_font)
    draw.text((x_time, 15), time_label, fill="black", font=station_font)

    try:
        if old_fontmode is not None:
            draw.fontmode = old_fontmode
    except Exception:
        pass

    stations = river_doc.get("stations") or []
    x0 = 10
    y0 = 20
    gap = 15
    decimal_x = 310

    if len(stations) >= 1:
        used_h = _draw_station_graph(draw, label_font, stations[0], x0=x0, y0=y0)
        heights_0 = stations[0].get("heights_m") or []
        if heights_0:
            station_name_0 = str(stations[0].get("name", "")).strip()
            short_0 = (station_name_0.split() or [""])[0]

            old_fontmode = getattr(draw, "fontmode", None)
            try:
                draw.fontmode = "1"
            except Exception:
                pass

            draw.text((decimal_x - 25, y0 + 28), short_0, fill="black", font=station_font)
            
            # Use red for height label if value >= top_of_normal_range
            height_color = "black"
            top_of_normal = stations[0].get("top_of_normal_range_m")
            if isinstance(top_of_normal, (int, float)) and float(heights_0[-1]) >= top_of_normal:
                height_color = "red"
            
            _draw_large_height(draw, large_font, float(heights_0[-1]), decimal_x=decimal_x, y=y0 + 48, color=height_color)

            try:
                if old_fontmode is not None:
                    draw.fontmode = old_fontmode
            except Exception:
                pass
        y0 = y0 + used_h + gap

    if len(stations) >= 2:
        _draw_station_graph(draw, label_font, stations[1], x0=x0, y0=y0)
        heights_1 = stations[1].get("heights_m") or []
        if heights_1:
            station_name_1 = str(stations[1].get("name", "")).strip()
            short_1 = (station_name_1.split() or [""])[0]

            old_fontmode = getattr(draw, "fontmode", None)
            try:
                draw.fontmode = "1"
            except Exception:
                pass

            draw.text((decimal_x - 25, y0 + 28), short_1, fill="black", font=station_font)
            
            # Use red for height label if value >= top_of_normal_range
            height_color = "black"
            top_of_normal = stations[1].get("top_of_normal_range_m")
            if isinstance(top_of_normal, (int, float)) and float(heights_1[-1]) >= top_of_normal:
                height_color = "red"
            
            _draw_large_height(draw, large_font, float(heights_1[-1]), decimal_x=decimal_x, y=y0 + 48, color=height_color)

            try:
                if old_fontmode is not None:
                    draw.fontmode = old_fontmode
            except Exception:
                pass

    return img


def render_latest_3color_png(river_doc: dict) -> bytes:
    """Generate 3-color PNG with red elements."""
    img = _render_latest_image(river_doc)
    out = io.BytesIO()
    img.save(out, format="PNG")
    return out.getvalue()


def render_latest_png(river_doc: dict) -> bytes:
    """Generate 2-color PNG by converting 3-color image to black & white.
    
    Red pixels are converted to black for 2-color displays.
    """
    img_3color = _render_latest_image(river_doc)
    width, height = img_3color.size
    img_bw = Image.new("RGB", (width, height), "white")
    pixels_3color = img_3color.load()
    pixels_bw = img_bw.load()
    
    for y in range(height):
        for x in range(width):
            r, g, b = pixels_3color[x, y]
            # Check if pixel is red (high red, low green/blue) or black
            is_red = (r > 200 and g < 100 and b < 100)
            is_black = (r < 100 and g < 100 and b < 100)
            
            if is_red or is_black:
                # Convert red and black to black
                pixels_bw[x, y] = (0, 0, 0)
            else:
                # Keep white as white
                pixels_bw[x, y] = (255, 255, 255)
    
    out = io.BytesIO()
    img_bw.save(out, format="PNG")
    return out.getvalue()


def render_latest_mono_hlsb_black(river_doc: dict) -> bytes:
    """Generate 2-color framebuffer by converting 3-color image to black & white."""
    img_3color = _render_latest_image(river_doc)
    mono = img_3color.convert("1", dither=Image.Dither.NONE)
    width, height = mono.size
    if width != 400 or height != 300:
        raise ValueError(f"Expected 400x300 image, got {width}x{height}")

    pixels = mono.load()
    out = bytearray((width * height) // 8)

    idx = 0
    for y in range(height):
        for x_byte in range(0, width, 8):
            b = 0
            for bit in range(8):
                x = x_byte + bit
                px = pixels[x, y]
                if px:
                    b |= 1 << (7 - bit)
            out[idx] = b
            idx += 1

    return bytes(out)


def render_latest_3color_bin(river_doc: dict) -> bytes:
    """Generate 3-color framebuffer: 15000 bytes black plane + 15000 bytes red plane.
    
    Total: 30000 bytes for 400x300 display with black and red channels.
    """
    img = _render_latest_image(river_doc)
    width, height = img.size
    if width != 400 or height != 300:
        raise ValueError(f"Expected 400x300 image, got {width}x{height}")

    pixels = img.load()
    black_plane = bytearray((width * height) // 8)
    red_plane = bytearray((width * height) // 8)

    idx = 0
    for y in range(height):
        for x_byte in range(0, width, 8):
            black_byte = 0
            red_byte = 0
            for bit in range(8):
                x = x_byte + bit
                r, g, b = pixels[x, y]
                
                # Check if pixel is red (high red, low green/blue)
                is_red = (r > 200 and g < 100 and b < 100)
                # Check if pixel is black (all channels low)
                is_black = (r < 100 and g < 100 and b < 100)
                
                # Note: Waveshare driver inverts red plane with ~redImage[...] on transmit
                # So we need to invert our encoding:
                # - White: black=1, red=0 (driver inverts red to 1 = no red shown)
                # - Black: black=0, red=0 (driver inverts red to 1 = no red shown)
                # - Red:   black=1, red=1 (driver inverts red to 0 = red shown)
                
                if not is_black and not is_red:
                    # White: set black bit, clear red bit
                    black_byte |= 1 << (7 - bit)
                    # red_byte bit stays 0
                elif is_red:
                    # Red: set both bits (driver will invert red to show red)
                    black_byte |= 1 << (7 - bit)
                    red_byte |= 1 << (7 - bit)
                else:
                    # Black: clear both bits (both stay 0)
                    pass
            
            black_plane[idx] = black_byte
            red_plane[idx] = red_byte
            idx += 1

    # Concatenate black plane followed by red plane
    return bytes(black_plane + red_plane)
